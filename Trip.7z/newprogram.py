#cameorn#
#Comp prog#
#10 5 18%

from tkinter import *
from tkinter import ttk
global option
def hello():
    print ("hello!")

def exitt():
    quit()
    
cal = 0
priceopt = 0
pricefruit = 5
pricetotal = 0
root = Tk()
###########[MENU]##################################
menubar = Menu(root)

filemenu = Menu(menubar, tearoff=0)
filemenu.add_command(label="Save", command=hello)
filemenu.add_command(label="Exit", command=exitt)

menubar.add_cascade(label="File", menu=filemenu)

editmenu = Menu(menubar, tearoff=0)
editmenu.add_command(label="About", command=hello)

menubar.add_cascade(label="Help", menu=editmenu)
root.config(menu=menubar)
#########[FRAEM]###################################
buttframe = Frame(root, height=100, width=100)
buttframe.grid(column=2,row=2)

country_var = StringVar()
country = Listbox(root, listvariable=country_var, height=5)
country.bind("<<ListboxSelected>>", "+")
country.grid(column=0, row=1, sticky='NSEW')


country_label = Label(root, text="List of countrys!")
country_label.grid(column=0,row=0, sticky='NSEW')



s = ttk.Scrollbar(root, orient=VERTICAL, command=country.yview)
s.grid(column=1, row=1, sticky='NSEW')
country['yscrollcommand'] = s.set



textvar = StringVar()
t = Text(root, width=25, height=10)
t.grid(column=2, row=1)
notes_label = Label(root, text="Notes")
notes_label.grid(column=2,row=0)


optvar = StringVar()
option = ttk.Combobox(root, textvariable = optvar, state="readonly",width=15)
option['values'] = ('Air','Train','Car') ; opttemp = ['Air','Train','Car']

option.grid(column=0, row=3)
option_label = Label(root, text="Travel")
option_label.grid(column=0, row=2, sticky='NSEW')



ttk.Sizegrip().grid(column=5, row=5, sticky='NSEW')

root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_columnconfigure(2, weight=1)
root.grid_columnconfigure(3, weight=1)
root.grid_columnconfigure(4, weight=1)

calc_b = Button(buttframe, text='Calculate',bg='gray45', fg='white', width=10, state=NORMAL) #submit and clear#
clear_b = Button(buttframe, text='Clear', bg='gray65', fg='white', width=10, state=NORMAL) #submit and clear#
calc_b.grid(column=3,row=3)
clear_b.grid(column=4,row=3)

root.title('Price Calculator')

file = open('country.txt','r')
filer = file.read()
filers = filer.split('\n')
country_list = []
for x in filers:
    country_list.append(x)

for y in country_list:
    country.insert('end',y)
root.mainloop()
